from ia01.utils import*
from ia01.utils import*
from ia01.majoritaire import*
from ia01.metriques import*
from ia01.evaluation import*
from ia01.arbre import*



data_test=lecture_csv("data/X_test (1).csv")
data_trainy=lecture_csv("data/y_train (1).csv")
data_trainx=lecture_csv("data/X_train (2).csv")

champs=[keys for keys in data_test[0]]

x_train=[]
for d in data_trainx:
    xt=[]
    for ch in champs:
        xt.append(int(d[ch]))
    x_train.append(xt)

x_test=[]
for d in data_test:
    xh=[]
    for ch in champs:
        xh.append(int(d[ch]))
    x_test.append(xh)

l=[keys for keys in data_trainy[0]]
y_train=[]
for keys in l:
    t=[]
    for value in data_trainy:
        t.append(value[keys])
    y_train.append(t)
#on essaie i de 0 à 12 cad sur tous les types de music 
i=3
arbre = arbre_train(x_train, y_train[i],max_prof=3)
K = 5
X_K, y_K =partition_val_croisee(x_train,y_train[i], K)
prof = list(range(20)) + [float("inf")]
erreur = [0] * len(prof)
for i in range(K):
    X_val, y_val = X_K[i], y_K[i]
    X_train, y_train = [], []
    for j in range(K):
        if j != i:
            X_train += X_K[j]
            y_train += y_K[j]
    arbre = arbre_train(X_train, y_train,max_prof=20)
    for j, p in enumerate(prof):
        y_pred_val = arbre_pred(X_val, arbre, max_prof=p)
        erreur[j] +=taux_erreur(y_val, y_pred_val) / K
bestp_e = argsort(erreur)[0]
print(f"Profondeur optimale : prof = {bestp_e}")
