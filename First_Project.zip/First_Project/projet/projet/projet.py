from ia01.utils import*
from ia01.utils import*
from ia01.majoritaire import*
from ia01.metriques import*
from ia01.evaluation import*
from ia01.arbre import*


def ecriture_csv_projet(y_pred, fichier, sep=","):
    musique = [
        "Variete Francaise",
        "Pop / Rock",
        "Rap / Hip-Hop",
        "Classique",
        "Jazz",
        "Dance",
        "Electronique",
        "Metal",
        "R&B",
        "Soul",
        "Reggae",
        "Musique du monde",
        "Autres genres",
    ]
    C = len(musique)
    assert len(y_pred) == 486, "Les prédictions doivent contenir 486 données."
    for y in y_pred:
        assert len(y) == C, "Une prédiction doit être de longueur 13."
    with open(fichier, "w") as f:
        for i, m in enumerate(musique):
            f.write(m)
            if i < C - 1:
                f.write(sep)
        f.write("\n")
        for y in y_pred:
            for i, y_ in enumerate(y):
                f.write(str(y_))
                if i < C - 1:
                    f.write(sep)
            f.write("\n")


data_test=lecture_csv("data/X_test (1).csv")
data_trainy=lecture_csv("data/y_train (1).csv")
data_trainx=lecture_csv("data/X_train (2).csv")

champs=[keys for keys in data_test[0]]

x_train=[]
for d in data_trainx:
    xt=[]
    for ch in champs:
        xt.append(int(d[ch]))
    x_train.append(xt)

x_test=[]
for d in data_test:
    xh=[]
    for ch in champs:
        xh.append(int(d[ch]))
    x_test.append(xh)

l=[keys for keys in data_trainy[0]]
y_train=[]
for keys in l:
    t=[]
    for value in data_trainy:
        t.append(value[keys])
    y_train.append(t)


y_pred=[]
for y in y_train:
    arbre = arbre_train(x_train,y,max_prof=3)
    y_pred1= arbre_pred(x_test, arbre, max_prof=3)
    y_pred.append(y_pred1)


y_pred_music=[]
for i in range(len(x_test)):
    l=[]
    for msc in y_pred:
        l.append(msc[i])
    y_pred_music.append(l)

ecriture_csv_projet(y_pred_music,"data/y_test.csv", sep=",")