# Travaux dirigés du cours IA01

Travaux dirigés du cours IA01
